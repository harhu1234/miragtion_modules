# -*- coding: utf-8 -*-
# Freight forwarding management module
{
    'name' : 'Project Task Notifications - ZorgCoach',
    'version' : '14.0',
    'summary': 'Project Task Notifications - ZorgCoach',
    'description': """
Project Task Notifications - ZorgCoach
    """,
    'category': 'General',
    'author': 'IvoAbels',
    'images' : [],
    'depends' : ['project','mass_mailing'],
    'data': [
        'data/project_task_data.xml'
    ],
    'demo': [
    ],
    'qweb': [
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
