# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api,fields, models,_

class GymOffer(models.Model):
    _name = 'offer.offer'
    _description = 'Offers for customers.'
    _inherit = 'mail.thread'

    name  = fields.Char(string='Name',tracking=True)
    description = fields.Text(string='Description')
    discount_type = fields.Selection([('fixed','Fixed'),('percentage','Percentage')])
    discount_amount = fields.Float(string='Discount')
    from_date = fields.Date(string='Start Date',tracking=True)
    to_date = fields.Date(string='End Date')
    code = fields.Char(string='Code',copy=False,default=lambda self:_(' New'),tracking=True)
    state = fields.Selection([('draft','New'),('running','Running'),('close','Closed')], default='draft')
    
# code generate for the offer form

    @api.model
    def create(self,vals):
        if vals.get('code',_('New')) == _('New'):
            vals['code'] = self.env['ir.sequence'].next_by_code('offer.offer') or _('New')
        res = super(GymOffer,self).create(vals)
        return res

    def offer_confirm(self):
        if self.state == 'draft':
            self.state = 'running'

    def offer_close(self):
        self.state = 'close'

    def redraft(self):
        self.state = 'draft'
