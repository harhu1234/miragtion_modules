# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import fields,api,models
from datetime import date
from dateutil.relativedelta import relativedelta

class WorkoutPlan(models.Model):

    _name = 'workout.plan'
    _rec_name = 'name'
    _description = 'Workout Plan'
    _inherit = 'mail.thread'


    name = fields.Char(string='Name',tracking=True)
    description = fields.Text(string='Description')
    duration = fields.Selection([('weekly','Weekly'),('monthly','Monthly')], string='Duration',tracking=True)
    from_date = fields.Date(string='From Date',tracking=True)
    to_date = fields.Date(string='To Date')
    activity_ids = fields.One2many('plan.activity','work_plan_id',string='Activity',tracking=True)
    image = fields.Binary(string='Image',tracking=True)
    state = fields.Selection([('draft','Draft'),('confirm','Confirm'),('approve','Approved')],string="Status",default="draft")
 

    def workout_plan_confirm(self):
        if self.state == 'draft':
            self.state = 'confirm'

    def workout_plan_approve(self):
        self.state = 'approve'

    def redraft(self):
        self.state = 'draft'

    @api.onchange('from_date')
    def check_to_date(self):
        if self.from_date and self.duration == 'weekly':
            self.to_date = self.from_date + relativedelta(days=7)
        elif self.from_date and self.duration == 'monthly':
            self.to_date = self.from_date + relativedelta(months=1)

