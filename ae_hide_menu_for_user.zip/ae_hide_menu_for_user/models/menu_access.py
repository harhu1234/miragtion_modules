# -*- coding: utf-8 -*-
##############################################################################
#
#    AtharvERP Business Solutions
#    Copyright (C) 2020-TODAY AtharvERP Business Solutions(<http://www.atharverp.com>).
#    Author: AtharvERP Business Solutions(<http://www.atharverp.com>)
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import models, fields, api, _


class ir_menu_access(models.Model):
    _name = 'ir.menu.access'
    _description = 'Menu Access'

    group_ids = fields.Many2many('res.groups', 'rel_menu_access_group',
                                 'access_id', 'group_id', 'Groups')
    user_ids = fields.Many2many('res.users', 'rel_menu_access_users',
                                 'access_id', 'user_id', 'Users')
    menu_ids = fields.Many2many('ir.ui.menu', 'rel_menu_access_menus',
                                 'access_id', 'menu_id', 'Menus')