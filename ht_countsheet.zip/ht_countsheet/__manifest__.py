{
	'name':'Countsheet',
	'version':'14.0.0.1',
	'category':'Inventory Management',
	'summary':'Added product and location barcode to count sheet report.',
	'description':""" Added product and location barcode to count sheet report.""",
	'depends':['stock'],
	'data':[
	    'report/inventory_count_report.xml',
       	],
	'demo':[],
	'installable':True,
	'auto-install':False,

}
