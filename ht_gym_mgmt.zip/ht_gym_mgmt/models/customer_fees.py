# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api,fields, models,_
from datetime import date, datetime
from odoo.exceptions import UserError, ValidationError

class CustomerFees(models.Model):
    _name = 'customer.fees'
    _inherit = 'mail.thread'
    _description = 'Customer Fees'
    _rec_name = 'booking_id'

    date = fields.Date(string='Date')
    amount_due = fields.Float(string='Due Amount' )
    fees_amount = fields.Float(string='Fees Paid', default="")
    booking_id = fields.Many2one('customer.booking', string='Booking Id')
    state = fields.Selection([('draft','Draft'),('confirm','Confirm'),('approve','Approved')],string="Status",default="draft")

    # calculate due fees
    @api.onchange('fees_amount')
    def calculate_DueFees(self):
        self.amount_due = 0
        if self.booking_id.price:
            if self.fees_amount <= self.booking_id.total_amount:
                for i in self:

                    i.amount_due = i.booking_id.total_amount - i.fees_amount
            else:
                raise ValidationError(_('Please do not enter amount more than Your total amount')) 


    def fee_reminder(self):
        print("...........fee reminder..............................")

    def fees_confirm(self):
        if self.state == 'draft':
            self.state = 'confirm'

    def fees_approve(self):
        self.state = 'approve'

    def redraft(self):
        self.state = 'draft'

    @api.onchange('date')
    def check_date(self):
        if self.date:
            if self.date != date.today():
                raise ValidationError(_('Please select today date'))

# 