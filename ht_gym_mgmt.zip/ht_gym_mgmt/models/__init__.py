# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from . import gym_membership
from . import gym_course
from . import customer_booking
from . import inherit_partner
from . import course_batch
from . import gym_features
from . import customer_offer
from . import customer_fees
from . import trainee_analysis
from . import trainee_report
from . import gym_activity
from . import work_schedule
from . import schedule_activity
from . import workout_plan
from . import plan_activity

