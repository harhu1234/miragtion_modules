# -*- coding: utf-8 -*-
{
    'name': 'Stock Location Priority',
    'summary': "Stock Details",
    'description': "Stock Location Priority",
    'version': '14.0.0.0.1',
    'category': 'Base',
    'author': 'Jupical Technologies Pvt. Ltd.',
    'maintainer': 'Jupical Technologies Pvt. Ltd.',
    'website': 'http://jupical.com/',
    'depends': ['stock'],
    'data': [
            'views/stock_location.xml',
    ],
    'license': 'AGPL-3',
}

