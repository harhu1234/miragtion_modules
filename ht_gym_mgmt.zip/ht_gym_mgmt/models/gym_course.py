# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api,fields, models,_
from dateutil.relativedelta import relativedelta


class GymCourse(models.Model):
    _name='course.course'
    _description = 'Gym Course'
    _inherit = 'mail.thread'

    name = fields.Char(string='Name',tracking=True)
    bo_course_id = fields.Many2one('course.course', string='Course Name')
    duration_type = fields.Selection([('month','Month'),('year','Year')], string="Duration Type")
    duration = fields.Integer(string='Duration',tracking=True)
    description = fields.Text(string='Description')
    image = fields.Binary(string='Image',attachment=True)
    price = fields.Float(string='Course Fees',tracking=True)
    extras = fields.Many2many('features.features',string="Extra Features")
    batch_ids = fields.One2many('course.batch','course_id', string='Batches')
    feature_sum = fields.Float(string='Amount',tracking=True)
    state = fields.Selection([('draft','Draft'),('confirm','Confirm'),('approve','Approved')],string="Status",default="draft")
    course_fee_id = fields.Many2one('customer.booking',string='Course Fee')
    trainee_count = fields.Integer(string='Trainee Count', compute='check_trainee_count')

# function to calculate total price

    @api.onchange('price','extras')
    def CalculatePrice(self):
        sum = 0 
        for rec in self.extras:
            sum += self.extras.feature_price
        self.feature_sum = sum + self.price

    def course_confirm(self):
        if self.state == 'draft':
            self.state = 'confirm'

    def course_approve(self):
        self.state = 'approve'

    def redraft(self):
        self.state = 'draft'

    @api.onchange('duration','duration_type')
    def calculate_end_date(self):
        if self.duration_type and self.duration:
            for date in self.batch_ids:
                if self.duration_type == 'year':
                    date.end_date = date.start_date + relativedelta(years=self.duration)

                elif self.duration_type == 'month':
                    date.end_date = date.start_date + relativedelta(months=self.duration)

                else:
                    pass

# check for trainee count as per courses
    @api.depends()
    def check_trainee_count(self):
        for rec in self:
            count = self.env['trainee.report'].search_count([('course_id','=',rec.name)])
            rec.trainee_count = count
