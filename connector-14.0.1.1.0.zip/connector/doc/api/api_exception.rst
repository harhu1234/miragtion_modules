Exceptions
==========

.. automodule:: connector.exception
   :members:
   :undoc-members:
   :show-inheritance:
