# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import fields,api,models
from datetime import date

class PlanActivity(models.Model):

    _name = 'plan.activity'
    _rec_name = 'work_plan_id'
    _description = 'Plan Activity'
    _inherit = 'mail.thread'

    work_plan_id = fields.Many2one('workout.plan',string='Work out ID',tracking=True)
    activity_date = fields.Date(string='Date',tracking=True)
    activty_gym_id = fields.Many2one('gym.activity', string='Activity',tracking=True)
    description = fields.Text(string='Description')
    work_time = fields.Float(string='Time',tracking=True)
    state = fields.Selection([('draft','Draft'),('confirm','Confirm'),('approve','Approved')],string="Status",default="draft",tracking=True)


    def plan_activity_confirm(self):
        if self.state == 'draft':
            self.state = 'confirm'

    def plan_activity_approve(self):
        self.state = 'approve'

    def redraft(self):
        self.state = 'draft'
