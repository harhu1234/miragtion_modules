# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api,fields, models,_
from odoo.exceptions import UserError, ValidationError

class Membership(models.Model):
    _name = 'customer.membership'
    _inherit = 'mail.thread'
    _rec_name = 'name'
    _description = 'Gym Customer Membership'

    name = fields.Char(string='Name', required=True, copy=False,tracking=True)
    membership = fields.Selection([('month','Month'),('year','Year')],string='Membership')
    membership_count = fields.Integer('Count',compute='check_count')
    duration = fields.Integer(string='Duration',tracking=True)
    description = fields.Text(string='Description for the Membership')
    # purpose = fields.Selection([('general','General Fitness'),('weightloss','Weight Loss'),('tournament','Tournament')],string='Purpose')
    coach = fields.Boolean(string='Coach?')
    coach_id = fields.Many2one('res.partner', string='Coach Name')
    price = fields.Float(string='Price')
    image = fields.Binary(string='Image',attachment=True)
    is_active = fields.Boolean(string='Active',tracking=True, readonly=True,)
    state = fields.Selection([('draft','Draft'),('confirm','Confirm'),('approve','Approved')],string="Status",default="draft")
    user_id = fields.Many2one('res.users',string="User")
    featurs_ids = fields.Many2many('features.features', string='Features')
    membership_amount = fields.Float('Total amount',tracking=True)
    user_id = fields.Many2one('res.users', string="Set User")
    follow_id = fields.Many2one('mail.threa', string='Follower')
    customer_count_id = fields.Many2one('customer.booking', string='Counts')
    feature_count = fields.Integer(string='Feature Count')

#unique membership name 
    _sql_constraints = [('unique_membership','unique(name)','Sorry! you can chooose another name')]

    
# funtion to check if month is selected greater than 12.

    @api.constrains('membership')
    def CheckMonth(self):
        for rec in self:
            if (self.membership == 'month' and self.duration > 12):
                raise ValidationError(_('Please choose Year for duration or Choose months less than 12'))

    @api.onchange('price','featurs_ids')
    def total_amount(self):
        for o in self:
            if o.price:
                o.membership_amount = o.price
                if o.featurs_ids:
                    for line in o.featurs_ids:
                        o.membership_amount = o.price + line.feature_price

# calculate customer count for membership
    @api.depends()
    def check_count(self):
        for rec in self:
            count = self.env['customer.booking'].search_count([('membership','=',rec.name)])
            rec.membership_count = count

# calculation of membership features
    @api.onchange('featurs_ids')
    def count_features(self):
        if self.featurs_ids:
            for rec in self:
                rec.feature_count = len(rec.featurs_ids)

    def confirm_membership(self):
        if self.state == 'draft':
            self.state = 'confirm'

    def approve(self):
        self.state = 'approve'
        self.is_active = True

    def redraft(self):
        self.state = 'draft'

    # def name_get(self):
    #     booking_list = []
    #     for booking in self:
    #         name = booking.name + '(' + booking.duration + '  ' + booking.membership + ')'
    #         booking_list.append(booking.id, name)
    #     return booking_list
