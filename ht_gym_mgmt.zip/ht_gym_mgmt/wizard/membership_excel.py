# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api,fields, models,_,tools
from datetime import date, datetime
import xlwt
import io
import base64
from xlwt import easyxf 
from xlwt import Workbook
from PIL import Image
from resizeimage import resizeimage
from odoo.tools.misc import xlsxwriter
from odoo.modules.module import get_resource_path

class MembershipXslxReport(models.Model):
    _name="membership.xlsx.report"
    _description = "Membership Excel Report"

    excel_file = fields.Binary(string='File')
    filename = fields.Char(string='File name')

    def print_membership_xls(self):
        output = io.BytesIO()

        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet(_('Membership Report'))
        table_header = workbook.add_format({'align':'center','bg_color':'#9ba5c1','border': 1})
        line_style = workbook.add_format({'align': 'center','border':1})
        heading = workbook.add_format({'align':'center', 'bold':True,'border':1,'bg_color':'#2448a9','font_color':'#f5f7fa'})
        line_s = workbook.add_format({'align':'center','bold':True, 'border':1})

        file_name = 'membership.xls'
        row = 0
        col = 0

        sheet.merge_range(row,col,6,4,'')
        if self.env.user.company_id:
            filename = 'logo.png'
            image_data = io.BytesIO(base64.standard_b64decode(self.env.user.company_id.logo))
            sheet.insert_image(0,0,filename,{'image_data' : image_data,'x_offser':7,'y_offset':7,'x_scale':0.5,'y_scale':0.7})

        invoice_ids = self.env['customer.membership'].browse(self.env.context.get('active_ids'))
        for line in invoice_ids:
            if line.user_id.company_id:
                address = ''

                address += line.user_id.company_id.name + '\n'
                address += line.user_id.company_id.street + '\n'  
                address += line.user_id.company_id.city + '\n'
                address += line.user_id.company_id.state_id.name + '\n'
                address += line.user_id.company_id.zip + '\n'
                address += line.user_id.company_id.country_id.name + '\n'
            
                sheet.write(row,col,address,line_style)

        row+=9
        col=0
        sheet.merge_range(row,col,9,col+3,'')
        sheet.write(row,col,_('Membership'),heading)
        row+=1
        sheet.set_column(col, col,25)
        sheet.write(row,col,_('Name:'),table_header)
        col +=1
        sheet.set_column(col, col,15)
        sheet.write(row,col,_('Duration'),table_header)
        col +=1 
        sheet.set_column(col, col,15)
        sheet.write(row,col,_('Active'),table_header)
        col += 1
        sheet.set_column(col, col, 15)
        sheet.write(row,col,_('Total Amount'), table_header)

        row+=1
        col=0

        for member in invoice_ids:
            if member.name:
                duration = ''

                duration += str(member.duration) + ' '
                duration += member.membership + ''

                sheet.write(row,col,member.name,line_style)
                col+=1
                sheet.write(row,col,duration,line_style)
                col+=1
                sheet.write(row,col,member.is_active,line_style)
                col+=1
                sheet.write(row,col,member.membership_amount,line_s)
                col+=1

        workbook.close()

        xlsx_data = base64.encodestring(output.getvalue())

        res_id = self.env['membership.xlsx.report'].create(
        {'excel_file': xlsx_data, 'filename': file_name})


        return {
            'name': 'Download Files',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': False,
            'res_model': 'membership.xlsx.report',
            'domain': [],
            'type': 'ir.actions.act_window',
            'target': 'new',
            'res_id': res_id.id,
            'context': {'active_ids': self.env.context.get('active_ids')}
        }
