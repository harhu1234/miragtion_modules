# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import fields,api,models
from datetime import date

class GymWorkSchedule(models.Model):

    _name = 'work.schedule'
    _rec_name = 'course'
    _description = 'Work Scedule'
    _inherit = 'mail.thread'

    partner_id = fields.Many2one('res.partner',string='Name',tracking=True)
    course = fields.Many2one('course.course',string="Course Name")
    from_date = fields.Date(string='From Date',tracking=True)
    to_date = fields.Date(string='To Date')
    activity_ids = fields.One2many('schedule.activity','activity_id',string='Activity')
    standard_plan = fields.Boolean(string='Workout Plan?',tracking=True)
    state = fields.Selection([('draft','Draft'),('confirm','Confirm'),('approve','Approved')],string="Status",default="draft")
    work_plan = fields.Many2one('workout.plan', string="Workout Plan")

    @api.constrains('to_date')
    def CheckDates(self):
        for rec in self:
            if (self.from_date > self.to_date):
                raise ValidationError(_('Please Enter To date bigger than From date'))

    def schedule_confirm(self):
        if self.state == 'draft':
            self.state = 'confirm'

    def schedule_approve(self):
        self.state = 'approve'

    def redraft(self):
        self.state = 'draft'

    @api.onchange('work_plan')
    def add_plan_activities(self):
        plan_line = self.env['workout.plan'].search([('name','=',self.work_plan.name)])
        plan_work = self.env['schedule.activity']
        new_plan = []
        for lines in plan_line.activity_ids:
            lines_val = {
                'activity_date' : lines.activity_date,
                'gym_activity_id' : lines.activty_gym_id.id,
                'description' : lines.description,
                'work_time': lines.work_time,
            }
            new_plan.append((0,0, lines_val))
            print("...........activity_id............",lines.work_plan_id.id)
        self.write({'activity_ids' : new_plan})
        
