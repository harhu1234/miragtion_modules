# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

{
    'name':'Gym MGMT',
    'version':'14.0.0.1.0',
    'summary': 'Complete Gym Management Application with website and business operation Features.',
    'author': 'Harhu IT Solutions',
    'maintainer': 'Harhu IT Solutions',
    'contributors': ["Harhu IT Solutions"],
    'website': 'http://www.harhu.com',
    'depends':['contacts','hr'],
    'data':[
        'security/gym_security.xml',
        'security/ir.model.access.csv',
        'data/ir_sequence_data.xml',
        'data/scheduled_actions.xml',
        'data/mail_template.xml',
        'data/renewal_template.xml',
        'data/scheduled_actions.xml',
        'views/gym_membership_views.xml',
        'views/customer_booking_views.xml',
        'views/inherit_partner_views.xml',
        'views/gym_course_views.xml',
        'views/course_batch_views.xml',
        'views/gym_features_views.xml',
        'views/customer_offer_views.xml',
        'views/customer_fees_views.xml',
        'views/trainee_analysis_views.xml',
        'views/trainee_report_views.xml',
        'reports/reports.xml',
        'views/gym_activity_views.xml',
        'views/work_schedule_views.xml',
        'views/schedule_activity_views.xml',
        'views/workout_plan_views.xml',
        'views/plan_activity_views.xml',
        'reports/membership_report.xml',
        'reports/customer_by_membership_report.xml',
        'reports/course_report.xml',
        'reports/batch_report.xml',
        'reports/offer_report.xml',
        'reports/feature_report.xml',
        'reports/membership_features_report.xml',
        'reports/trainee_analysis_report.xml',
        'reports/trainee_offers_report.xml',
        'reports/booking_by_day_report.xml',
        'reports/all_coach_report.xml',
        'wizard/membership_excel_views.xml',
        'wizard/booking_excel_views.xml',
        'wizard/course_excel_views.xml',
        'wizard/offer_excel_views.xml',
        'wizard/features_excel_views.xml',
        'wizard/course_batch_excel_views.xml',
        'wizard/trainee_analysis_excel_views.xml',
        
    ],
    'installable': True,
    'auto_install': False,
}
