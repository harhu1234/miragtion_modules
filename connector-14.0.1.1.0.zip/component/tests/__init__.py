from . import test_build_component
from . import test_component
from . import test_lookup
from . import test_work_on
