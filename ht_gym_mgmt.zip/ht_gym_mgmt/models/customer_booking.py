# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api,fields, models,_
from datetime import datetime, timedelta, date
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta
import smtplib
from babel.dates import format_datetime, format_date

class GymBooking(models.Model):
    _name = 'customer.booking'
    _rec_name = 'partner_id'
    _description = 'Bookings created by members'
    _inherit = 'mail.thread'

    partner_id = fields.Many2one('res.partner', string='Name',tracking=True)
    email = fields.Char(string='Email Id',related='partner_id.email')
    mobile = fields.Char(string='Mobile',related='partner_id.mobile')
    birth_date = fields.Date(string='Birth Date',related='partner_id.member_dob')
    is_membership = fields.Boolean(string='Membership?',tracking=True)
    is_activate = fields.Boolean(string='Active',tracking=True,default='Active')
    membership = fields.Many2one('customer.membership',string='Membership',domain="[('is_active','=', True)]")
    booking_count = fields.Integer('Booking count',compute='check_booking_count')
    need_coach = fields.Many2one('res.partner', string="Coach Name")
    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date',readonly=True)
    price = fields.Float(string='Price',tracking=True)
    shift = fields.Selection([('morning','Morning'),('evening','Evening')],string='Shift')
    workout_hour = fields.Float(string='Workout Time',tracking=True)
    month_year = fields.Selection([('month','Month'),('year','Year')],string='Duration Type')
    duration = fields.Integer(string='Duration')
    state = fields.Selection([('draft','Draft'),('confirm','Confirm'),('approve','Approved')],string="Status",default="draft")
    offer_id = fields.Many2one('offer.offer',string='Offers')
    gym_ids = fields.One2many('course.course','course_fee_id', string='Course Id')
    booking_fees_ids = fields.One2many('customer.fees', 'booking_id', string="Fees")
    follow = fields.Many2one('mail.thread', string='follower')
    body = 'Hello There, you are assigned to new gym member'
    paid_fees = fields.Float(string='Paid Fees',compute='action_booking_fees')
    # measurement for the excercise chart

    height = fields.Float(string='Height')
    arms = fields.Float(string='Arms')
    chest = fields.Float(string='Chest')
    waist = fields.Float(string='Waist')
    hips = fields.Float(string='Hips')
    shoulder = fields.Float(string='Shoulder')
    thigh = fields.Float(string='Thigh')
    weight = fields.Float(string='Weight')

    due_fees = fields.Float(string='Due Amount')
    total_amount = fields.Float(string="Total Amount", readonly=True)
    course_amount = fields.Float(string="Total course price", readonly=True)

# for total amount
    @api.onchange('price')
    def check_price(self):
        if self.price:
            self.total_amount = self.price

# membership price total  
    @api.onchange('membership')
    def check_membership_price(self):
        if self.membership:
            self.price = self.membership.price
            self.total_amount = self.price

# calculate course price
    @api.onchange('gym_ids')
    def cal_course_amount(self):
        for rec in self:
            if rec.price:
                rec.total_amount = rec.price

                if rec.gym_ids:
                    total = 0
                    rec.course_amount = total

                    for i in rec.gym_ids:
                        if i.bo_course_id and i.feature_sum:
                            total += i.feature_sum
                            rec.course_amount = total
                    
                            rec.total_amount = rec.price + rec.course_amount

# calculate offer amount
    @api.onchange('offer_id')
    def cal_offer(self):
        if self.price:
            if self.offer_id:
                self.price -= self.offer_id.discount_amount

#calculate due amount
    @api.onchange('booking_fees_ids')
    def cal_due_amount(self):
        if self.price:
            for rec in self:
                for i in rec.booking_fees_ids:
                    rec.due_fees = i.amount_due

#sending email to coach as per the booking
    @api.model
    def create(self, vals):
        result = super(GymBooking, self).create(vals)
        if result.is_membership == True:
            if result.membership.coach == True:
                follower = result.membership.coach_id
                reg = { 
                       'res_id': result.id, 
                       'res_model': 'customer.booking', 
                       'partner_id': follower.id, 
                      } 
                follower_id = self.env['mail.followers'].create(reg)
                self.env['mail.mail'].sudo().create({
                                                    'email_from': 'ruchita.harhu@gmail.com',
                                                    'body_html': self.body,
                                                    'subject': 'Customer Registration',
                                                    'email_to': result.membership.coach_id.email,
                                                    'auto_delete': True,
                                                
                                                }).send()
        return result 

# fucntion to check date should not be of past
    @api.constrains('end_date')
    def CheckDates(self):
        for rec in self:
            if (self.start_date > self.end_date):
                raise ValidationError(_('Please Enter End date bigger than Start date'))

# autofill end_date from start date

    @api.onchange('start_date')
    def get_end_date(self):
        if self.is_membership == True:
            chk_type = self.env['customer.membership'].search([('name','=',self.membership.name)])
            get_type = chk_type.membership
            get_duration = chk_type.duration
            
            if chk_type.membership == 'month':
                self.end_date  = self.start_date + relativedelta(months=get_duration)
            elif chk_type.membership == 'year':
                self.end_date = self.start_date + relativedelta(years=get_duration)
            else:
                pass
        elif self.month_year == 'month':
            self.end_date  = self.start_date + relativedelta(months=self.duration)

        elif self.month_year == 'year':
            self.end_date = self.start_date + relativedelta(years=self.duration)
        else:
            pass
# autofill coach if member have active membership
    @api.onchange('membership')
    def add_coach(self):
        if self.membership:
            self.need_coach = self.membership.coach_id

# if booking falls under offer than provide discount

    @api.onchange('offer_id')
    def CheckDiscount(self):
        if self.offer_id:
            if self.start_date <= self.offer_id.to_date and self.start_date >= self.offer_id.from_date:
                if self.offer_id.discount_type == 'fixed':
                    discount = self.price - self.offer_id.discount_amount
                    self.price = discount
                
                elif self.offer_id.discount_type == 'percentage':
                    discount = self.price * (1 - self.offer_id.discount_amount / 100)
                    self.price = discount
            else:
               raise ValidationError(_('Sorry! there are no offers currently'))
            
    # @api.onchange('gym_ids','membership')
    # def set_price(self):
    #     if self.membership:
    #         if self.offer_id:
    #             for rec in self:
    #                 for line in rec.gym_ids:
    #                     rec.price = rec.membership.price + line.feature_sum - rec.offer_id.discount_amount
    #     else:
    #         print(".......................something is wrong.........................")
                    

#check for booking count as per dates
    @api.depends()
    def check_booking_count(self):
        for rec in self:
            count = self.env['customer.booking'].search_count([('start_date','=',rec.start_date)])
            rec.booking_count = count

# if membership than autofill duration
    @api.onchange('membership')
    def set_duration(self):
        if self.is_membership == True:
            self.month_year = self.membership.membership
            self.duration = self.membership.duration

#cron job functions 
    def expire_membership(self):
        for dates in self:
            if dates.end_date:
                check_dates = self.end_date == date.today()
                print("......check date.................",res)
                dates.is_activate = False
                print("...........membership expired..................")

    def renew_membership(self):
        # if self.end_date == date.today() or self.end_date < date.today():
        #     print(".......please renew........")
        print("............renew your membership..................")

    def send_email(self):
        # bdy = self.birth_date.strftime('%m-%d')
        # tdy_date = date.today().strftime('%m-%d')
        print("..............birthdate...................................................")
        # print(".................................today's date...................................",tdy_date)
        # if bdy < tdy_date:
        #     cron_email_id = self.env.ref('ht_gym_mgmt.email_booking_birthday')
        #     template = cron_email_id.send_mail(self.id, force_send=True)

    def renewal_request(self):
        tdy = today.strftime("%d/%m/%Y")
        if self.end_date <= tdy():
            renewal_email_id = self.env.ref('ht_gym_mgmt.renewal_membership')
            template_id = renewal_email_id.send_email(self.id, force=True)
        
    def redraft(self):
        self.state = 'draft'

    def booking_confirm(self):
        if self.state == 'draft':
            self.state = 'confirm'

    def booking_approve(self):
        self.state = 'approve'

   # display customer fees on smart button
    def action_booking_fees(self):
        paid_amount = 0
        print("HI.....")
        for rec in self:
            for paid_am in rec.booking_fees_ids:
                if paid_am.fees_amount:
                    print("...............amount.......................",paid_am.fees_amount)
                    paid_amount += paid_am.fees_amount
                    print(".......................check fees.............................",paid_amount)
        
            rec.paid_fees = paid_amount
       
# show due fees amount smart button
    def action_due_fees(self):
        if self.booking_fees_ids:
            for i in self.booking_fees_ids:
                self.due_fees = i.amount_due