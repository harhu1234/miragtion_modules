* Guewen Baconnier at Camptocamp
* Alexandre Fayolle at Camptocamp
* Benoit Guillot at Akretion
* Nicolas Bessi at Camptocamp
* Joël Grand-Guillaume at Camptocamp
* Arthur Vuillard at Akretion
* Sebastien Beau at Akretion
* Laurent Mignon at Acsone
* Leonardo Pistone at Camptocamp
* David Béal at Akretion
* Christophe Combelles at Anybox
* Stéphane Bidoul at Acsone
* Malte Jacobi at IBO / HTW
* Laetitia Gangloff at Acsone
* David Lefever at Taktik S.A.
* Jos de Graeve at Apertoso NV
* Jean-Sébastien Suzanne at Anybox
* Leonardo Donelli at MONK Software
* Mathias Colpaert
* Yannick Vaucher at Camptocamp
* Nicolas Piganeau at NDP Systèmes
* Florent Thomas at Mind And Go
* Matthieu Dietrich at Camptocamp
* Olivier Laurent at Acsone
* Eric Antones at NuoBiT Solutions S.L.
