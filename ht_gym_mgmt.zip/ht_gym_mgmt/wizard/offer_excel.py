# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api,fields, models,_,tools
from datetime import date, datetime
import xlwt
import io
import base64
from xlwt import easyxf 
from xlwt import Workbook
from PIL import Image
from resizeimage import resizeimage
from odoo.tools.misc import xlsxwriter
from odoo.modules.module import get_resource_path

class OfferXlsReport(models.Model):
    _name = 'offer.xlsx.report'
    _description = 'Excel report for all courses.'

    excel_file = fields.Binary(string='File')
    filename = fields.Char(string='File name')

    def print_offer_xls(self):
        output = io.BytesIO()

        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet(_('All Offer Report'))
        line_style = workbook.add_format({'align': 'center','border':1})
        table_header = workbook.add_format({'align':'center','bg_color':'#9ba5c1','border': 1})
        heading = workbook.add_format({'align':'center', 'bold':True,'border':1,'bg_color':'#2448a9','font_color':'#f5f7fa'})
        line_s = workbook.add_format({'align':'center','bold':True, 'border':1})
        bold   = workbook.add_format({'bold': True})

        file_name = 'offers.xls'
        row = 0
        col = 0
        
        sheet.merge_range(row,col,6,3,'')
        if self.env.user.company_id:
            filename = 'logo.png'
            image_data = io.BytesIO(base64.standard_b64decode(self.env.user.company_id.logo))
            sheet.insert_image(0,0,filename,{'image_data' : image_data,'x_offser':7,'y_offset':7,'x_scale':0.5,'y_scale':0.6})

        invoice_ids = self.env['offer.offer'].browse(self.env.context.get('active_ids'))
        
        for line in invoice_ids:
            
            if self.env.user.company_id:
                address = ''

                address += self.env.user.company_id.name + '\n'
                address += self.env.user.company_id.street + '\n'  
                address += self.env.user.company_id.city + ','
                address += self.env.user.company_id.state_id.name + '\n'
                address += self.env.user.company_id.zip + ','
                address += self.env.user.company_id.country_id.name + '\n'
                address += self.env.user.company_id.vat + ' | '
                address += self.env.user.company_id.company_registry + '\n'

                sheet.write(row,col,address,line_style)

        row+=9
        col=0

        sheet.merge_range(row,col,9,col+5,'')
        sheet.write(row,col,_('Offer Details'),heading)
        row+=1
        sheet.set_column(col, col,25)
        sheet.write(row,col,_('Name'),table_header)
        col +=1
        sheet.set_column(col, col,25)
        sheet.write(row,col,_('Description'),table_header)
        col +=1
        sheet.set_column(col, col,25)
        sheet.write(row,col,_('Discount'),table_header)
        col +=1
        sheet.set_column(col, col,15)
        sheet.write(row,col,_('Start Date'),table_header)
        col +=1
        sheet.set_column(col, col,15)
        sheet.write(row,col,_('End Date'),table_header)
        col += 1
        # sheet.set_column(col, col, 25)
        sheet.write(row,col,_('State'), table_header)

        row+=1
        col=0

        for member in invoice_ids:
            if member.name:

                sheet.write(row,col,member.name,line_style)
                col+=1
                sheet.write(row,col,member.description,line_style)
                col+=1
                start_date = member.from_date.strftime('%d/%m/%y')
                end_date = member.to_date.strftime('%d/%m/%y')
                discount = ''

                discount += str(member.discount_amount) + ' '
                discount +=  member.discount_type + ''

                sheet.write(row,col,discount,line_s)
                col+=1
                sheet.write(row,col,start_date,line_style)
                col+=1
                sheet.write(row,col,end_date,line_style)
                col+=1
                sheet.write(row,col,member.state,line_style)
                
                row+=1
                col=0
              
        workbook.close()

        xlsx_data = base64.encodestring(output.getvalue())

        res_id = self.env['offer.xlsx.report'].create(
        {'excel_file': xlsx_data, 'filename': file_name})


        return {
            'name': 'Download Files',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': False,
            'res_model': 'offer.xlsx.report',
            'domain': [],
            'type': 'ir.actions.act_window',
            'target': 'new',
            'res_id': res_id.id,
            'context': {'active_ids': self.env.context.get('active_ids')}
        }
