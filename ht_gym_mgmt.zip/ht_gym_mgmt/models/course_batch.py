# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api,fields, models,_
from datetime import date, datetime
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta

class CourseBatch(models.Model):
    _name = 'course.batch'
    _description = 'Gym Batches'
    _rec_name = 'shift'
    _inherit = 'mail.thread'

    name = fields.Char(string='Name',tracking=True)
    course_id = fields.Many2one('course.course')
    shift = fields.Selection([('morning','Morning'),('evening','Evening')],string='Shift',tracking=True)
    start_date = fields.Date(string='Start Date',tracking=True)
    end_date = fields.Date(string='End Date')
    trainee_limit = fields.Integer(string='Students per Batch')
    state = fields.Selection([('draft','Draft'),('confirm','Confirm'),('approve','Approved')],string="Status",default="draft")

# function to check date should not be of past.
    
    @api.constrains('start_date','end_date')
    def CheckPastDates(self):
        for rec in self:
            if self.start_date and self.end_date > date.today(): 
                if (self.start_date > self.end_date):
                    raise ValidationError(_('Please Enter End date bigger than Start date'))
            else:
                raise ValidationError(_('Please do not enter past dates'))

#name_get function for string combination
    
    # def name_get(self):
    #     batch_list = []
    #     for batches in self:
    #         name = batches.name + '  ('+ batches.shift + ')'
    #         batch_list.append((batches.id,name))
    #     return batch_list
                

    def batch_confirm(self):
        if self.state == 'draft':
            self.state = 'confirm'

    def batch_approve(self):
        self.state = 'approve'

    def redraft(self):
        self.state = 'draft'

    
