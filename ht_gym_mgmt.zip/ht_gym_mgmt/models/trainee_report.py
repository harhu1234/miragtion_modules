# -*- coding: utf-8 -*-

##############################################################################
#
#    Harhu Technologies Pvt. Ltd.
#    Copyright (C) 2019-Today Harhu Technologies Pvt. Ltd.(<http://www.harhu.com>).
#    Author: Harhu Technologies Pvt. Ltd. (<http://www.harhu.com>) Contact: <hello@harhu.com>
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api, fields, models
from datetime import date

class TraineeReport(models.Model):

    _name = 'trainee.report'
    _rec_name = 'trainee_analysis_id'
    _description = 'Reports for Trainee'
    _inherit = 'mail.thread'

    trainee_analysis_id = fields.Many2one('trainee.analysis',string='Trainee Analysis' , tracking=True)
    measure = fields.Selection([('weekly','Weekly'),('monthly','Monthly'),('yearly','Yearly')], )
    improve = fields.Boolean(string='Improve',tracking=True, )
    add_comments  = fields.Text(string='Comment',tracking=True)
    analysis_date = fields.Date(string='Date')
    need_more = fields.Boolean(string='Training Required',tracking=True)
    state = fields.Selection([('draft','Draft'),('confirm','Confirm'),('approve','Approved')],string="Status",default="draft")
    course_id = fields.Many2one('course.course',string='Courses')
    trainee_booking_id = fields.Many2one('customer.booking',string='Trainee')
    previous_date = fields.Date(string='Previous Measument Date')


# customer measurements
    re_height = fields.Float(string='Height')
    re_arms = fields.Float(string='Arms')
    re_chest = fields.Float(string='Chest')
    re_waist = fields.Float(string='Waist')
    re_hips = fields.Float(string='Hips')
    re_shoulder = fields.Float(string='Shoulder')
    re_thigh = fields.Float(string='Thigh')
    re_weight = fields.Float(string='Weight')

    @api.onchange('trainee_analysis_id')
    def calculate_last_date(self):
        if self.trainee_analysis_id:
            for rec in self:
                for dates in rec.trainee_analysis_id.line_ids:
                    pre_date = self.env['trainee.report'].search([('trainee_analysis_id','=',self.trainee_analysis_id.id)])
                    if pre_date:
                        for i in pre_date:
                            dat = i.create_date
                            self.previous_date = dat

    
